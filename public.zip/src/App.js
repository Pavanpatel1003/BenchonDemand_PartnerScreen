import React from 'react'
import AppRoutes from '../src/routes/AppRoutes'

const App = () => {
  return (
    <>
      <AppRoutes/>
    </>
  )
}

export default App
