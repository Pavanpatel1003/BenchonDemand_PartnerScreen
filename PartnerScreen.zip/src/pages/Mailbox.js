import React from "react";

const Mailbox = () => {
  return (
    <>
      <div class="container-fluid table-format">
        <h1>Mailbox</h1>
      </div>
    </>
  );
};

export default Mailbox;
