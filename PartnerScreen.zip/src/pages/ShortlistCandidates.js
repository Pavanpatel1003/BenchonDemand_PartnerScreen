import React from "react";

const ShortlistCandidates = () => {
  return (
    <>
      <div class="container-fluid table-format">
        <h1>Data not</h1>
      </div>
    </>
  );
};

export default ShortlistCandidates;
